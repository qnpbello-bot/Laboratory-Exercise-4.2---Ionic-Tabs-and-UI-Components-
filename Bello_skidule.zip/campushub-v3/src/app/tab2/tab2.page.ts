import { Component } from '@angular/core';
import {
  IonHeader,
  IonToolbar,
  IonContent,
  IonIcon,
  IonSearchbar,
  IonModal,
} from '@ionic/angular';
import { addIcons } from 'ionicons';
import {
  searchOutline,
  closeOutline,
  calendarClearOutline,
} from 'ionicons/icons';

interface Post {
  title: string;
  category: string;
  group: string;
  body: string;
  more: string;
  date: string;
  image: string;
  wash: string;
  ink: string;
}

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss'],
  imports: [
    IonHeader,
    IonToolbar,
    IonContent,
    IonIcon,
    IonSearchbar,
    IonModal,
  ],
})
export class Tab2Page {
  filters = ['All', 'Announcements', 'Events', 'Updates'];
  activeFilter = 'All';
  searching = false;
  query = '';
  openedPost: Post | null = null;

  posts: Post[] = [
    {
      title: 'Spring Break Dates',
      category: 'Academic Calendar',
      group: 'Announcements',
      body:
        'Spring break will begin on March 24 and classes will resume April 1. Students are encouraged to check their schedules before the break.',
      more:
        'Dormitories stay open for the duration, but the meal plan pauses from March 25. Residents staying on campus should sign the housing list at the Student Affairs desk before Friday.',
      date: 'Mar 10, 2025',
      image: 'https://picsum.photos/seed/campusquad/900/600',
      wash: 'var(--ch-blue-wash)',
      ink: 'var(--ch-blue)',
    },
    {
      title: 'Library Hours Update',
      category: 'Campus Update',
      group: 'Updates',
      body:
        'The university library will now remain open until 10:00 PM from Monday to Friday to provide students with additional study time.',
      more:
        'Third-floor study rooms can be booked in two-hour blocks at the front desk or through the campus portal. Weekend hours are unchanged.',
      date: 'Mar 8, 2025',
      image: 'https://picsum.photos/seed/readingroom/900/600',
      wash: 'var(--ch-mint)',
      ink: 'var(--ch-mint-ink)',
    },
    {
      title: 'Student Organization Fair',
      category: 'Events',
      group: 'Events',
      body:
        'Discover new organizations, meet fellow students, and find opportunities to get involved on campus.',
      more:
        'Held at the covered court from 9:00 AM to 4:00 PM. Over forty organizations will have booths, and most accept sign-ups on the spot.',
      date: 'Mar 5, 2025',
      image: 'https://picsum.photos/seed/orgfair/900/600',
      wash: 'var(--ch-lavender)',
      ink: 'var(--ch-lavender-ink)',
    },
    {
      title: 'Graduation Application Reminder',
      category: 'General',
      group: 'Announcements',
      body:
        'The deadline to apply for graduation is April 15. Make sure to complete your application on time.',
      more:
        'Applications are submitted through the registrar portal. Late submissions move your clearance to the following term, so check your remaining units before filing.',
      date: 'Mar 1, 2025',
      image: 'https://picsum.photos/seed/gradcap/900/600',
      wash: 'var(--ch-peach)',
      ink: 'var(--ch-peach-ink)',
    },
    {
      title: 'Shuttle Route Change at Gate 3',
      category: 'Campus Update',
      group: 'Updates',
      body:
        'Construction closes the east driveway until April. Shuttles will pick up at the covered court instead.',
      more:
        'Departures run every fifteen minutes from 6:30 AM. The last trip leaves at 8:00 PM on weekdays and 5:00 PM on Saturdays.',
      date: 'Feb 26, 2025',
      image: 'https://picsum.photos/seed/shuttlebus/900/600',
      wash: 'var(--ch-mint)',
      ink: 'var(--ch-mint-ink)',
    },
    {
      title: 'Intramurals Opening Ceremony',
      category: 'Events',
      group: 'Events',
      body:
        'The annual intramurals open with a parade of colleges, followed by the first round of basketball and volleyball.',
      more:
        'Assembly is at 7:00 AM at the oval. Classes from 7:00 AM to 12:00 NN are suspended for the day.',
      date: 'Feb 20, 2025',
      image: 'https://picsum.photos/seed/intrams/900/600',
      wash: 'var(--ch-peach)',
      ink: 'var(--ch-peach-ink)',
    },
  ];

  // Both controls narrow the same list. A getter recomputes on every
  // change with nothing to subscribe to or keep in sync.
  get visiblePosts(): Post[] {
    const q = this.query.trim().toLowerCase();

    return this.posts.filter((p) => {
      const inGroup =
        this.activeFilter === 'All' || p.group === this.activeFilter;

      const inQuery =
        q === '' ||
        p.title.toLowerCase().includes(q) ||
        p.body.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q);

      return inGroup && inQuery;
    });
  }

  toggleSearch() {
    this.searching = !this.searching;
    if (!this.searching) {
      this.query = '';
    }
  }

  openPost(post: Post) {
    this.openedPost = post;
  }

  constructor() {
    addIcons({ searchOutline, closeOutline, calendarClearOutline });
  }
}
