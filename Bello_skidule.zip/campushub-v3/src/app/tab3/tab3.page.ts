import { Component, inject } from '@angular/core';
import {
  IonHeader,
  IonToolbar,
  IonContent,
  IonAvatar,
  IonList,
  IonItem,
  IonLabel,
  IonIcon,
  IonToggle,
  IonModal,
  AlertController,
  ToastController,
  ToggleCustomEvent,
} from '@ionic/angular';
import { addIcons } from 'ionicons';
import {
  settingsOutline,
  moonOutline,
  notificationsOutline,
  mailOutline,
  personCircleOutline,
  helpCircleOutline,
  logOutOutline,
  chevronForwardOutline,
} from 'ionicons/icons';

interface Setting {
  id: string;
  name: string;
  hint: string;
  icon: string;
  enabled: boolean;
}

interface Stat {
  value: string;
  label: string;
  detail: string;
}

const STORAGE_KEY = 'campushub.settings';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss'],
  imports: [
    IonHeader,
    IonToolbar,
    IonContent,
    IonAvatar,
    IonList,
    IonItem,
    IonLabel,
    IonIcon,
    IonToggle,
    IonModal,
  ],
})
export class Tab3Page {
  private alerts = inject(AlertController);
  private toasts = inject(ToastController);

  student = {
    name: 'Nikko Paulo Bello',
    role: 'Computer Science Student',
    tagline: 'Better days ahead.',
  };

  // Drop your own picture at src/assets/avatar.jpg and it appears
  // here. If the file is missing the (error) handler swaps in a
  // placeholder rather than showing a broken image.
  photo = 'assets/avatar.jpg';
  photoOpen = false;

  stats: Stat[] = [
    {
      value: '12',
      label: 'Courses',
      detail: 'Enrolled in 12 courses this term, 18 units total.',
    },
    {
      value: '248',
      label: 'Followers',
      detail: '248 students follow your activity.',
    },
    {
      value: '176',
      label: 'Following',
      detail: 'You follow 176 students and organizations.',
    },
  ];

  settings: Setting[] = [
    {
      id: 'dark',
      name: 'Enable Dark Mode',
      hint: 'Use a darker appearance',
      icon: 'moon-outline',
      enabled: false,
    },
    {
      id: 'push',
      name: 'Push Notifications',
      hint: 'Receive campus announcements',
      icon: 'notifications-outline',
      enabled: true,
    },
    {
      id: 'email',
      name: 'Email Updates',
      hint: 'Receive important university emails',
      icon: 'mail-outline',
      enabled: true,
    },
  ];

  actions = [
    {
      id: 'account',
      label: 'Account Settings',
      icon: 'person-circle-outline',
      danger: false,
    },
    {
      id: 'help',
      label: 'Help & Support',
      icon: 'help-circle-outline',
      danger: false,
    },
    { id: 'logout', label: 'Log Out', icon: 'log-out-outline', danger: true },
  ];

  onPhotoError() {
    this.photo = 'https://i.pravatar.cc/300?img=12';
  }

  openPhoto() {
    this.photoOpen = true;
  }

  async onToggle(setting: Setting, event: ToggleCustomEvent) {
    setting.enabled = event.detail.checked;

    if (setting.id === 'dark') {
      document.documentElement.classList.toggle(
        'ion-palette-dark',
        setting.enabled,
      );
    }

    this.save();
    await this.toast(
      `${setting.name} ${setting.enabled ? 'on' : 'off'}`,
    );
  }

  async openStat(stat: Stat) {
    await this.toast(stat.detail);
  }

  async openSettings() {
    const alert = await this.alerts.create({
      header: 'Settings',
      message:
        'Language: English<br>Region: Philippines<br>Storage used: 48 MB',
      buttons: ['Close'],
    });
    await alert.present();
  }

  async runAction(id: string) {
    if (id === 'account') {
      const alert = await this.alerts.create({
        header: 'Account Settings',
        message:
          'Student number: 2023-104882<br>Email: npbello&#64;tip.edu.ph<br>Program: BS Computer Science',
        buttons: ['Close'],
      });
      await alert.present();
      return;
    }

    if (id === 'help') {
      const alert = await this.alerts.create({
        header: 'Help & Support',
        message:
          'Registrar: local 2110<br>IT Helpdesk: local 2145<br>Guidance Office: local 2130',
        buttons: ['Close'],
      });
      await alert.present();
      return;
    }

    // Destructive actions get a confirmation with the cancel listed
    // first, so the safe choice is the one nearest the thumb.
    const confirm = await this.alerts.create({
      header: 'Log out?',
      message: 'You will need to sign in again to see your schedule.',
      buttons: [
        { text: 'Cancel', role: 'cancel' },
        {
          text: 'Log out',
          role: 'destructive',
          handler: () => this.toast('Logged out'),
        },
      ],
    });
    await confirm.present();
  }

  private async toast(message: string) {
    const t = await this.toasts.create({
      message,
      duration: 1600,
      position: 'bottom',
      cssClass: 'ch-toast',
    });
    await t.present();
  }

  // Settings survive a reload. localStorage is fine here because this
  // is a real app in a real browser, not a sandboxed preview.
  private save() {
    const state: Record<string, boolean> = {};
    this.settings.forEach((s) => (state[s.id] = s.enabled));
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }

  private restore() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return;

      const state = JSON.parse(raw) as Record<string, boolean>;
      this.settings.forEach((s) => {
        if (typeof state[s.id] === 'boolean') s.enabled = state[s.id];
      });

      const dark = this.settings.find((s) => s.id === 'dark')?.enabled ?? false;
      document.documentElement.classList.toggle('ion-palette-dark', dark);
    } catch {
      // Corrupt or blocked storage just means defaults. Not worth
      // interrupting the user over.
    }
  }

  constructor() {
    addIcons({
      settingsOutline,
      moonOutline,
      notificationsOutline,
      mailOutline,
      personCircleOutline,
      helpCircleOutline,
      logOutOutline,
      chevronForwardOutline,
    });
    this.restore();
  }
}
