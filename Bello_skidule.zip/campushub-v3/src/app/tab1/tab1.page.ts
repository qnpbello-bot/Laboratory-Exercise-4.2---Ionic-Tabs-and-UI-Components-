import { Component, inject } from '@angular/core';
import {
  IonHeader,
  IonToolbar,
  IonContent,
  IonList,
  IonItem,
  IonLabel,
  IonIcon,
  IonModal,
  AlertController,
} from '@ionic/angular';
import { addIcons } from 'ionicons';
import {
  notificationsOutline,
  codeSlashOutline,
  laptopOutline,
  bookOutline,
  peopleOutline,
  locationOutline,
  chevronForwardOutline,
  calendarClearOutline,
  timeOutline,
  cafeOutline,
  flaskOutline,
  calculatorOutline,
  barbellOutline,
} from 'ionicons/icons';

interface Block {
  title: string;
  start: string;
  end: string;
  room: string;
  instructor: string;
  note: string;
  icon: string;
  wash: string;
  ink: string;
}

const BLUE = { wash: 'var(--ch-blue-wash)', ink: 'var(--ch-blue)' };
const MINT = { wash: 'var(--ch-mint)', ink: 'var(--ch-mint-ink)' };
const LAV = { wash: 'var(--ch-lavender)', ink: 'var(--ch-lavender-ink)' };
const PEACH = { wash: 'var(--ch-peach)', ink: 'var(--ch-peach-ink)' };

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
  imports: [
    IonHeader,
    IonToolbar,
    IonContent,
    IonList,
    IonItem,
    IonLabel,
    IonIcon,
    IonModal,
  ],
})
export class Tab1Page {
  private alerts = inject(AlertController);

  firstName = 'Nikko';
  today = 23;
  selectedDate = 23;
  unread = 3;
  openedBlock: Block | null = null;

  week = [
    { dow: 'Sun', date: 20, label: 'Sun, Apr 20' },
    { dow: 'Mon', date: 21, label: 'Mon, Apr 21' },
    { dow: 'Tue', date: 22, label: 'Tue, Apr 22' },
    { dow: 'Wed', date: 23, label: 'Wed, Apr 23' },
    { dow: 'Thu', date: 24, label: 'Thu, Apr 24' },
    { dow: 'Fri', date: 25, label: 'Fri, Apr 25' },
    { dow: 'Sat', date: 26, label: 'Sat, Apr 26' },
  ];

  // The whole week, keyed by date. Tapping a day in the strip just
  // moves selectedDate; every getter below reads from this map, so
  // the heading, the count, the pips and the list all follow from
  // one piece of state.
  schedule: Record<number, Block[]> = {
    20: [],
    21: [
      {
        title: 'CS 101: Intro to Angular',
        start: '8:00 AM',
        end: '9:30 AM',
        room: 'Room 302',
        instructor: 'Dr. Reyes',
        note: 'Bring your laptop. We are covering standalone components and dependency injection.',
        icon: 'code-slash-outline',
        ...BLUE,
      },
      {
        title: 'MATH 212: Discrete Structures',
        start: '10:00 AM',
        end: '11:30 AM',
        room: 'Room 118',
        instructor: 'Prof. Alcantara',
        note: 'Problem set 4 is due at the start of class.',
        icon: 'calculator-outline',
        ...LAV,
      },
    ],
    22: [
      {
        title: 'IT 204: Web Development',
        start: '9:00 AM',
        end: '11:00 AM',
        room: 'Computer Lab 1',
        instructor: 'Engr. Domingo',
        note: 'Lab exercise 4.2. Have your Ionic project running before the session starts.',
        icon: 'laptop-outline',
        ...MINT,
      },
      {
        title: 'PE 2: Swimming',
        start: '3:00 PM',
        end: '4:00 PM',
        room: 'Aquatics Center',
        instructor: 'Coach Lim',
        note: 'Swim cap required. Attendance is counted from the first whistle.',
        icon: 'barbell-outline',
        ...PEACH,
      },
    ],
    23: [
      {
        title: 'CS 101: Intro to Angular',
        start: '8:00 AM',
        end: '9:30 AM',
        room: 'Room 302',
        instructor: 'Dr. Reyes',
        note: 'Quiz on component lifecycle. Covers everything from week one to week five.',
        icon: 'code-slash-outline',
        ...BLUE,
      },
      {
        title: 'IT 204: Web Development',
        start: '10:00 AM',
        end: '11:30 AM',
        room: 'Computer Lab 1',
        instructor: 'Engr. Domingo',
        note: 'Continuation of the CampusHub build. Bring your laptop charger.',
        icon: 'laptop-outline',
        ...MINT,
      },
      {
        title: 'ENG 102: Communication',
        start: '1:00 PM',
        end: '2:30 PM',
        room: 'Room 105',
        instructor: 'Ms. Villanueva',
        note: 'Group presentations. Ten minutes per group, five for questions.',
        icon: 'book-outline',
        ...LAV,
      },
      {
        title: 'Study Time',
        start: '4:00 PM',
        end: '5:00 PM',
        room: 'University Library',
        instructor: 'Third floor, room 3B',
        note: 'Booked under your name. The room releases after fifteen minutes if nobody checks in.',
        icon: 'people-outline',
        ...PEACH,
      },
    ],
    24: [
      {
        title: 'CHEM 101: General Chemistry',
        start: '8:30 AM',
        end: '10:30 AM',
        room: 'Science Lab 2',
        instructor: 'Dr. Santos',
        note: 'Titration lab. Closed shoes and a lab gown are required to enter.',
        icon: 'flask-outline',
        ...MINT,
      },
      {
        title: 'MATH 212: Discrete Structures',
        start: '1:00 PM',
        end: '2:30 PM',
        room: 'Room 118',
        instructor: 'Prof. Alcantara',
        note: 'Graph theory. Review the adjacency matrix handout beforehand.',
        icon: 'calculator-outline',
        ...LAV,
      },
    ],
    25: [
      {
        title: 'ENG 102: Communication',
        start: '9:00 AM',
        end: '10:30 AM',
        room: 'Room 105',
        instructor: 'Ms. Villanueva',
        note: 'Peer review workshop. Bring two printed copies of your draft.',
        icon: 'book-outline',
        ...LAV,
      },
      {
        title: 'Org Meeting: CS Society',
        start: '4:00 PM',
        end: '5:30 PM',
        room: 'Student Center',
        instructor: 'Open to all members',
        note: 'Planning for the org fair. Snacks provided.',
        icon: 'people-outline',
        ...PEACH,
      },
    ],
    26: [],
  };

  // Reading from the map rather than storing a second copy means the
  // list can never drift out of sync with the selected date.
  get blocks(): Block[] {
    return this.schedule[this.selectedDate] ?? [];
  }

  get selectedLabel(): string {
    return this.week.find((d) => d.date === this.selectedDate)?.label ?? '';
  }

  get headingPrefix(): string {
    if (this.selectedDate === this.today) return 'Today';
    if (this.selectedDate === this.today + 1) return 'Tomorrow';
    return this.selectedDate < this.today ? 'Earlier' : 'Upcoming';
  }

  get greeting(): string {
    const h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 18) return 'Good afternoon';
    return 'Good evening';
  }

  get greetingNote(): string {
    const n = this.schedule[this.today]?.length ?? 0;
    if (n === 0) return 'Nothing scheduled today. Enjoy the break.';
    return `You have ${n} ${n === 1 ? 'session' : 'sessions'} today.`;
  }

  countFor(date: number): number {
    return this.schedule[date]?.length ?? 0;
  }

  selectDay(date: number) {
    this.selectedDate = date;
  }

  openBlock(block: Block) {
    this.openedBlock = block;
  }

  async openNotifications() {
    this.unread = 0;
    const alert = await this.alerts.create({
      header: 'Notifications',
      message:
        'Quiz in CS 101 moved to 8:15 AM.<br><br>' +
        'Computer Lab 1 reopened after maintenance.<br><br>' +
        'Library room 3B booking confirmed.',
      buttons: ['Got it'],
      cssClass: 'ch-alert',
    });
    await alert.present();
  }

  constructor() {
    addIcons({
      notificationsOutline,
      codeSlashOutline,
      laptopOutline,
      bookOutline,
      peopleOutline,
      locationOutline,
      chevronForwardOutline,
      calendarClearOutline,
      timeOutline,
      cafeOutline,
      flaskOutline,
      calculatorOutline,
      barbellOutline,
    });
  }
}
