Put your profile photo in this folder and name it exactly:

    avatar.jpg

The Profile tab loads assets/avatar.jpg. If the file is missing, the
page falls back to a placeholder image instead of showing a broken
icon, so the app still runs either way.

A square crop looks best - the avatar is a circle, so anything tall or
wide gets cut off at the sides.
